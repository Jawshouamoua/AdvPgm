#include <iostream>
#include <vector>
using namespace std;

class List {

	private:
		struct TreeNode {
			Object element;
			TreeNode *firstChild;
			TreeNode *nextSibling;
		} ;



